
# 仁济医院医患app项目

## 项目依赖安装

```
$ yarn install
# OR
$ npm install
```

### 项目启动

```
$ npm run dev
```

### 项目编译打包

```
$ npm build
```